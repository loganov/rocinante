# rocinante

## Usage
* Port is on 3000. Can be set to 80 via port forwarding. Running Nodejs as root
is insane and that is what is required for node/node to run on port 80. Or a
reverse proxy would work. 
